function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
}
// Emojis representando o campo e a cidade

const emojisCampo = ['🌾', '🚜', '🐄', '🌻'];

const emojisCidade = ['🏙️', '🚇', '🏢', '🎡'];

// Lista combinada de emojis

let emojis = [];

let emojiCorreto;

let score = 0;

let rodada = 0;

const totalRodadas = 5;

function setup() {

  createCanvas(windowWidth, windowHeight);

  textSize(48);

  textAlign(CENTER, CENTER);

  noLoop();

  iniciarRodada();

}

function draw() {

  background(255);

  // Exibe o emoji correto

  fill(0);

  textSize(64);

  text(emojiCorreto, width / 2, height / 4);

  // Exibe as opções de emojis

  fill(0);

  textSize(48);

  for (let i = 0; i < emojis.length; i++) {

    text(emojis[i], width / 2, height / 2 + i * 100);

  }

  // Exibe a pontuação

  fill(0);

  textSize(32);

  text('Pontuação: ' + score, width / 2, height - 50);

}

function iniciarRodada() {

  emojis = [];

  let emojisDisponiveis = random() > 0.5 ? emojisCampo : emojisCidade;

  emojiCorreto = random(emojisDisponiveis);

  emojis.push(emojiCorreto);

  // Preenche as opções com emojis aleatórios

  while (emojis.length < 4) {

    let emojiAleatorio = random(emojisDisponiveis);

    if (!emojis.includes(emojiAleatorio)) {

      emojis.push(emojiAleatorio);

    }

  }

  // Embaralha as opções

  emojis = shuffle(emojis);

}

function mousePressed() {

  if (rodada < totalRodadas) {

    // Verifica se o clique foi no emoji correto

    let yPos = height / 2;

    for (let i = 0; i < emojis.length; i++) {

      if (dist(mouseX, mouseY, width / 2, yPos + i * 100) < 50) {

        if (emojis[i] === emojiCorreto) {

          score++;

        } else {

          score--;

        }

        rodada++;

        if (rodada < totalRodadas) {

          iniciarRodada();

          loop();

        } else {

          noLoop();

          fill(0);

          textSize(64);

          text('Fim de Jogo! Pontuação Final: ' + score, width / 2, height / 2);

        }

        break;

      }

    }

  }

}

